# Wytwórnia Zieleni - Hreflang Data

Dane hreflang dla strony [wytwornia-zieleni.pl](https://wytwornia-zieleni.pl)

## 🚀 Instalacja krok po kroku

### 1. Utwórz repozytorium na GitHub

1. Zaloguj się na [github.com](https://github.com)
2. Kliknij **"+"** → **"New repository"**
3. Nazwa: `wytwornia-hreflang`
4. Ustaw jako **Public**
5. Kliknij **"Create repository"**

### 2. Wgraj pliki

1. W nowym repo kliknij **"Add file"** → **"Upload files"**
2. Przeciągnij pliki: `hreflang.json` i `index.html`
3. Kliknij **"Commit changes"**

### 3. Włącz GitHub Pages

1. W repo przejdź do **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: **main** / **root**
4. Kliknij **Save**
5. Poczekaj 1-2 minuty

### 4. Sprawdź czy działa

Wejdź na:
```
https://TWOJ-USERNAME.github.io/wytwornia-hreflang/hreflang.json
```
Powinieneś zobaczyć JSON z danymi.

### 5. Zaktualizuj kod na stronie

W pliku `head-complete-optimized.html` zamień wszystkie wystąpienia:
```
TWOJ-USERNAME
```
na Twoją nazwę użytkownika GitHub.

### 6. Wklej kod do Divhunt

1. Skopiuj zawartość `head-complete-optimized.html`
2. W Divhunt wklej do odpowiednich sekcji (Head Start, Head End, Body Start)
3. Usuń stary kod hreflang i skryptów

---

## 📝 Jak aktualizować gdy dodasz nową stronę EN

### Strona z identyczną ścieżką PL/EN:
Dodaj ścieżkę do tablicy `identicalPaths` w `hreflang.json`:
```json
"identicalPaths": [
    ...,
    "/nowa-strona"
]
```

### Strona z różnymi slugami:
Dodaj mapowanie do `customMapping`:
```json
"customMapping": {
    ...,
    "/blog/polski-slug": "/en/blog/english-slug"
}
```

Po edycji → commit → zmiany będą widoczne po wygaśnięciu cache (max 7 dni) lub po wyczyszczeniu localStorage przez użytkownika.

---

## 📊 Statystyki

- Strony z identycznymi ścieżkami: 37
- Strony z custom mapowaniem: ~90
- Cache: 7 dni (localStorage)
- Zewnętrzne requesty: 1 na 7 dni per użytkownik

---

## ⚡ Korzyści vs stary kod

| Metryka | Stary kod | Nowy kod |
|---------|-----------|----------|
| Requesty/pageview | 2 (HEAD) | 0 (cache) |
| Blocking time | ~200ms | 0ms |
| Utrzymanie | Kod na stronie | JSON w GitHub |
